# 🚀 Signal AI Pro — Guide d'installation

## Installation en 3 étapes (GitHub Pages — GRATUIT)

### Étape 1 : Créer un compte GitHub
1. Va sur **github.com** et crée un compte gratuit

### Étape 2 : Créer le repository
1. Clique sur **"New repository"**
2. Nom : `signal-ai-pro`
3. Coche **"Public"**
4. Clique **"Create repository"**

### Étape 3 : Uploader les fichiers
1. Clique **"uploading an existing file"**
2. Glisse-dépose **TOUS les fichiers du ZIP** (index.html, manifest.json, sw.js, et le dossier icons/)
3. Clique **"Commit changes"**

### Étape 4 : Activer GitHub Pages
1. Va dans **Settings** → **Pages**
2. Source : **"Deploy from a branch"** → branch **main**
3. Clique **Save**
4. Après 1-2 minutes ton app est en ligne sur :
   `https://TON_USERNAME.github.io/signal-ai-pro`

---

## Installer sur Android

1. Ouvre Chrome Android
2. Va sur ton URL GitHub Pages
3. Un bandeau "Ajouter à l'écran d'accueil" apparaît
4. Ou : menu Chrome (⋮) → "Ajouter à l'écran d'accueil"
5. **L'app s'installe comme une vraie APK** ✅

## Installer sur iPhone (iOS)

1. Ouvre Safari
2. Va sur ton URL
3. Appuie sur le bouton **Partager** (carré avec flèche)
4. Sélectionne **"Sur l'écran d'accueil"**
5. Confirme **"Ajouter"**

---

## Fonctionnalités de l'app

- ✅ 3 onglets : Signal / Historique / Réglages
- ✅ Analyse IA (RSI, MACD, EMA, BB, Patterns)
- ✅ Confiance en % avec anneau visuel
- ✅ Historique des 50 derniers signaux (sauvegardé)
- ✅ Fonctionne hors-ligne (cache PWA)
- ✅ Vibration lors du signal
- ✅ Icône sur écran d'accueil
- ✅ Plein écran sans barre navigateur
